package List;




import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Live-
 */
public class LinkedList<E> {
//
//    private E obj;
//
//    List<? extends E> list;
//
//    public void addFirst(E obj) {
//        this.obj = obj;
//    }
//
//    public void addLast(E obj) {
//        this.obj = obj;
//    }
//
//    public E getFirst() {
//        return this.obj;
//    }
//
//    public E getLast() {
//        return this.obj;
//    }
//
//    public E removeFirst() {
//        return this.obj;
//    }
//
//    public E removeLast() {
//        return this.obj;
//    }

}
