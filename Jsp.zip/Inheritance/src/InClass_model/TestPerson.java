
package InClass_model;



public class TestPerson {

    public static void main(String[] args) {
//       Employee a = new Employee("Pichet Limvachiranan","0-2470-9872","pichet@sit.kmutt.ac.th",40000);
//        System.out.println(a);
//       System.out.println("--------------------------");
//       Student b = new Student("Paweena Thongyan",62130500053L);
//        System.out.println(b);
//        
//        System.out.println("---- a same b ?-----");
//       System.out.println(a.equals(b));
     B b = new B(2);
        
    }
}

class A {
 public A(){
             System.out.println("im A");
 }
         }

 class B extends A{
 public B(int t){
             System.out.println("im B");
 }
         }
 
