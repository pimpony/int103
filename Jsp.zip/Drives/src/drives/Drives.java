/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drives;

/**
 *
 * @author Live-
 */
public class Drives {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        pp p01 = new pp();
         cc p02 = new cc();
          cc p03 = new cc();
          
          System.out.println(p03.whoAmI());
    }
    
}



